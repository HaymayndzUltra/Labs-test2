#!/usr/bin/env python3
import os
import json
import uuid
import datetime
from pathlib import Path
from collections import OrderedDict

# Dynamic ROOT detection: prefer env, else walk up until .cursor found, else cwd
def _detect_root() -> Path:
    env_root = os.environ.get('CURSOR_WORKSPACE_ROOT') or os.environ.get('WORKSPACE_ROOT')
    if env_root:
        p = Path(env_root)
        if (p / '.cursor').exists():
            return p
    # Walk up from cwd to find a directory containing .cursor
    cur = Path.cwd()
    for _ in range(10):
        if (cur / '.cursor').exists():
            return cur
        if cur.parent == cur:
            break
        cur = cur.parent
    # Fallback to original default
    return Path('/workspace') if Path('/workspace/.cursor').exists() else Path.cwd()

ROOT = _detect_root()

# Caching controls
CACHE_DISABLED = os.environ.get('ROUTER_CACHE', '').lower() in ('off', '0', 'false')
LRU_MAX_SIZE = int(os.environ.get('ROUTER_LRU_SIZE', '512') or '512')

# Precedence cache
_PREC_CACHE: list[str] | None = None
_PREC_MTIME: float | None = None

# Policies cache
_POLICY_CACHE: list[dict] | None = None
_POLICY_MTIME: float | None = None

# LRU cache for decisions (keyed by epoch:normalized_context)
_LRU: OrderedDict[str, dict] = OrderedDict()
_CACHE_EPOCH = 0  # bumped when precedence/policies change
RULES_DIR = ROOT / '.cursor' / 'rules'
PRECEDENCE_FILE = RULES_DIR / 'master-rules' / '9-governance-precedence.mdc'
POLICY_DIR = ROOT / '.cursor' / 'dev-workflow' / 'policy-dsl'
ROUTING_LOG_SCHEMA = ROOT / '.cursor' / 'dev-workflow' / 'schemas' / 'routing_log.json'

def load_precedence():
    global _PREC_CACHE, _PREC_MTIME, _CACHE_EPOCH
    if not PRECEDENCE_FILE.exists():
        _PREC_CACHE = []
        _PREC_MTIME = None
        return _PREC_CACHE
    mtime = PRECEDENCE_FILE.stat().st_mtime
    if not CACHE_DISABLED and _PREC_CACHE is not None and _PREC_MTIME and abs(mtime - _PREC_MTIME) < 1.0:
        return _PREC_CACHE
    text = PRECEDENCE_FILE.read_text(encoding='utf-8')
    start = text.find('Priority Order')
    if start == -1:
        order = []
    else:
        block = text[start: start + 1000]
        lines = [l.strip() for l in block.splitlines() if l.strip().startswith('-')]
        order = [l.lstrip('-').strip().split(' ')[0] for l in lines]
    _PREC_CACHE = order
    # bump epoch if changed
    if _PREC_MTIME is None or abs(mtime - _PREC_MTIME) >= 1.0:
        _CACHE_EPOCH += 1
    _PREC_MTIME = mtime
    return order

def list_policies():
    global _POLICY_CACHE, _POLICY_MTIME, _CACHE_EPOCH
    if not POLICY_DIR.exists():
        _POLICY_CACHE = []
        _POLICY_MTIME = None
        return _POLICY_CACHE
    # compute dir mtime as max of files' mtimes
    mt = 0.0
    files = list(POLICY_DIR.glob('*.json'))
    for f in files:
        try:
            mt = max(mt, f.stat().st_mtime)
        except Exception:
            continue
    if not CACHE_DISABLED and _POLICY_CACHE is not None and _POLICY_MTIME and abs(mt - _POLICY_MTIME) < 1.0:
        return _POLICY_CACHE
    out = []
    for f in files:
        try:
            out.append(json.loads(f.read_text(encoding='utf-8')))
        except Exception:
            continue
    _POLICY_CACHE = out
    if _POLICY_MTIME is None or abs(mt - _POLICY_MTIME) >= 1.0:
        _CACHE_EPOCH += 1
    _POLICY_MTIME = mt
    return out

def _normalize_context(context_map) -> str:
    try:
        if isinstance(context_map, str):
            return context_map.strip().lower().replace('-', ' ')
        if isinstance(context_map, dict):
            tokens = []
            for v in context_map.values():
                if isinstance(v, (list, tuple, set)):
                    tokens.extend([str(x).strip().lower().replace('-', ' ') for x in v])
                else:
                    tokens.append(str(v).strip().lower().replace('-', ' '))
            return " ".join(tokens)
        return str(context_map).lower().replace('-', ' ')
    except Exception:
        return str(context_map).lower().replace('-', ' ')

def evaluate_policies(policies, context_map):
    # Normalize context values to a single lower-cased string for robust substring matching
    normalized_context = _normalize_context(context_map)
    matches = []
    for policy in policies:
        conditions = policy.get('conditions') or []
        conditions_lc = [str(c).lower() for c in conditions]
        if all(c in normalized_context for c in conditions_lc):
            matches.append(policy)
    # Primary ordering by priority (desc). Tie-break left as stable order for now
    matches.sort(key=lambda x: x.get('priority', 0), reverse=True)
    return matches

def route_decision(context):
    precedence = load_precedence()
    policies = list_policies()
    # LRU lookup
    normalized = _normalize_context(context)
    cache_key = f"{_CACHE_EPOCH}:{normalized}"
    cached = None
    if not CACHE_DISABLED:
        cached = _LRU.get(cache_key)
        if cached is not None:
            # move to end (most recently used)
            _LRU.move_to_end(cache_key)
            matched = cached.get('matched')
        else:
            matched = evaluate_policies(policies, context)
    else:
        matched = evaluate_policies(policies, context)
    # Tie-break using precedence_tag against precedence file when priorities tie
    if matched:
        # group by priority
        top_pri = matched[0].get('priority', 0)
        top = [p for p in matched if p.get('priority', 0) == top_pri]
        if len(top) > 1 and precedence:
            # build order map from precedence file
            prec_index = {k: i for i, k in enumerate(precedence)}
            def prec_rank(p):
                tag = p.get('precedence_tag')
                return prec_index.get(str(tag), len(prec_index))
            top.sort(key=prec_rank)
            winning = top[0]
        else:
            winning = matched[0]
    else:
        winning = None

    # Non-null, type-safe fields
    considered = []
    for p in matched:
        name = p.get('name')
        if isinstance(name, str) and name:
            considered.append(name)

    decision = 'none'
    if winning:
        win_name = winning.get('name')
        if isinstance(win_name, str) and win_name:
            decision = win_name

    log = {
        'session_id': str(uuid.uuid4()),
        'timestamp': datetime.datetime.utcnow().isoformat() + 'Z',
        'decision': decision,
        'confidence': 1.0 if winning else 0.0,
        'rules_considered': considered,
        'winning_rule': decision,
        'override_reason': None,
        'approver': None,
        'snapshot_id': context.get('snapshot_id')
    }
    # populate LRU
    if not CACHE_DISABLED:
        if cached is None:
            _LRU[cache_key] = {'matched': matched, 'decision': decision}
            if len(_LRU) > LRU_MAX_SIZE:
                _LRU.popitem(last=False)
        else:
            _LRU[cache_key]['decision'] = decision
    # persist to routing_logs dir
    outdir = ROOT / '.cursor' / 'dev-workflow' / 'routing_logs'
    outdir.mkdir(parents=True, exist_ok=True)
    fpath = outdir / (log['session_id'] + '.json')
    fpath.write_text(json.dumps(log, indent=2), encoding='utf-8')
    return log

if __name__ == '__main__':
    import sys
    ctx = {'git_commit':'', 'snapshot_id':None}
    if len(sys.argv) > 1:
        ctx['git_commit'] = sys.argv[1]
    res = route_decision(ctx)
    print(json.dumps(res, indent=2))

